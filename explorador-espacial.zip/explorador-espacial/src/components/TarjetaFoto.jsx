import { useState } from "react";
import "./TarjetaFoto.css";

function TarjetaFoto({ foto }) {
  const [abierta, setAbierta] = useState(false);
  const esImagen = foto.media_type === "image";

  return (
    <article className="tarjeta" onClick={() => setAbierta(!abierta)}>
      {esImagen ? (
        <img src={foto.url} alt={foto.title} />
      ) : (
        <div className="sin-imagen">Contenido de video</div>
      )}
      <h2>{foto.title}</h2>
      <p>{foto.date}</p>
      {abierta && <p className="explicacion">{foto.explanation}</p>}
    </article>
  );
}

export default TarjetaFoto;