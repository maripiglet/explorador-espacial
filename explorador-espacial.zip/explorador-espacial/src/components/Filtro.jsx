function Filtro({ valor, onCambiar }) {
  return (
    <label className="filtro">
      Tipo:
      <select value={valor} onChange={(e) => onCambiar(e.target.value)}>
        <option value="todos">Todos</option>
        <option value="image">Solo imágenes</option>
        <option value="video">Solo videos</option>
      </select>
    </label>
  );
}

export default Filtro;
