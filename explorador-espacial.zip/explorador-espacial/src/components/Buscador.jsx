import { useState } from "react";

function Buscador({ onBuscar }) {
  const [texto, setTexto] = useState("");

  function manejarCambio(e) {
    setTexto(e.target.value);
  }

  function manejarEnvio(e) {
    e.preventDefault();
    if (texto.trim() === "") return;
    onBuscar(texto.trim());
  }

  return (
    <form className="buscador" onSubmit={manejarEnvio}>
      <input
        type="text"
        value={texto}
        onChange={manejarCambio}
        placeholder="Busca en inglés: mars, nebula, galaxy..."
      />
      <button type="submit">Buscar</button>
    </form>
  );
}

export default Buscador;
