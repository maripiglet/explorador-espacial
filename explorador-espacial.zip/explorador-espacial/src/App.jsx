import { useState, useEffect } from "react";
import TarjetaFoto from "./components/TarjetaFoto";
import Buscador from "./components/Buscador";
import Filtro from "./components/Filtro";
import "./App.css";

async function buscarImagenes(termino) {
  const respuesta = await fetch(
    `https://images-api.nasa.gov/search?q=${encodeURIComponent(termino)}`
  );

  if (!respuesta.ok) {
    throw new Error(`Error HTTP ${respuesta.status}`);
  }

  const datos = await respuesta.json();

  return datos.collection.items.slice(0, 20).map((item) => ({
    key: item.data[0].nasa_id,
    title: item.data[0].title,
    date: item.data[0].date_created.slice(0, 10),
    explanation: item.data[0].description,
    media_type: item.data[0].media_type,
    url: item.links?.[0]?.href,
  }));
}

function App() {
  const [fotos, setFotos] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);
  const [termino, setTermino] = useState("galaxy");
  const [tipo, setTipo] = useState("todos");

  useEffect(() => {
    async function cargar() {
      setCargando(true);
      setError(null);
      try {
        const resultado = await buscarImagenes(termino);
        setFotos(resultado);
      } catch (err) {
        setError(err.message);
      } finally {
        setCargando(false);
      }
    }

    cargar();
  }, [termino]);

  // Filtro: no vuelve a consultar la API, solo revisa la lista ya cargada
  const fotosFiltradas = fotos.filter((foto) => {
    if (tipo === "todos") return true;
    return foto.media_type === tipo;
  });

  function manejarBusqueda(nuevoTermino) {
    setTermino(nuevoTermino);
  }

  return (
    <div className="app">
      <h1>Explorador Espacial</h1>
      <Buscador onBuscar={manejarBusqueda} />

      {cargando && <p className="mensaje">Buscando "{termino}"...</p>}

      {!cargando && error && (
        <p className="mensaje">Ocurrió un error: {error}</p>
      )}

      {!cargando && !error && fotos.length === 0 && (
        <p className="mensaje">No se encontraron resultados para "{termino}".</p>
      )}

      {!cargando && !error && fotos.length > 0 && (
        <>
          <Filtro valor={tipo} onCambiar={setTipo} />
          <p className="resumen">
            Resultados para "{termino}": {fotosFiltradas.length}
          </p>

          {fotosFiltradas.length === 0 ? (
            <p className="mensaje">No hay resultados de ese tipo.</p>
          ) : (
            <div className="cuadricula">
              {fotosFiltradas.map((foto) => (
                <TarjetaFoto key={foto.key} foto={foto} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;
